import { api, store } from "./api.js";
import { fuelShare } from "/shared/logic.js";
import * as view from "./views.js";

const s = {
  user: null, tab: "find", mode: "login", error: "",
  filters: { from: "", gate: "", time: "08:30", women: false },
  places: [], rides: [], bookings: [], hosting: [],
};
const root = document.getElementById("app");

const render = () => {
  root.innerHTML = s.user ? view.shell(s) : view.loginView(s);
  if (s.tab === "offer" && s.user) previewCost();
};

/* ---------- data loading ---------- */
const loadRides = async () => {
  const q = new URLSearchParams({ ...s.filters, women: s.filters.women ? "1" : "" });
  s.rides = await api("/rides?" + q);
};
const loadMine = async () => { [s.bookings, s.hosting] = await Promise.all([api("/me/bookings"), api("/me/hosting")]); };
const loadAll = async () => { s.places = await api("/places"); await Promise.all([loadRides(), loadMine()]); };

// Runs an action; errors show inside the form (keeping typed values) or in the page banner.
async function run(fn, form) {
  s.error = "";
  try { await fn(); } catch (e) {
    const box = form?.querySelector(".err");
    if (box) { box.textContent = e.message; return; }
    s.error = e.message;
  }
  render();
}

/* ---------- events ---------- */
const post = (path, body) => api(path, { method: "POST", body });
const fields = f => Object.fromEntries(new FormData(f));

const actions = {
  mode: el => { s.mode = el.dataset.value; render(); },
  signout: () => { post("/logout").catch(() => {}); store.token = ""; s.user = null; render(); },
  tab: el => run(async () => { s.tab = el.dataset.value; await Promise.all([loadRides(), loadMine()]); }),
  book: el => run(async () => { await post(`/rides/${el.dataset.id}/book`); await Promise.all([loadRides(), loadMine()]); s.tab = "mine"; }),
  confirm: el => run(async () => { await post(`/bookings/${el.dataset.id}/confirm`); await loadMine(); }),
};

const forms = {
  auth: async f => {
    const r = await post("/" + s.mode, fields(f));
    store.token = r.token; s.user = r.user; s.tab = "find";
    await loadAll();
  },
  offer: async f => {
    const d = fields(f);
    await post("/rides", { ...d, stops: d.stops.split(","), women: "women" in d });
    s.tab = "mine"; await Promise.all([loadRides(), loadMine()]);
  },
  review: async f => {
    const d = fields(f);
    await post(`/bookings/${f.dataset.id}/review`, { punctuality: +d.punctuality, safety: +d.safety, courtesy: +d.courtesy });
    await Promise.all([loadRides(), loadMine()]);
  },
};

function previewCost() {
  const f = document.querySelector("[data-form=offer]");
  if (!f) return;
  const two = f.type.value === "Two-Wheeler";
  if (two) f.seats.value = 1;
  f.seats.max = two ? 1 : 4;
  document.getElementById("cost").textContent = "₹" + fuelShare(+f.distance.value || 1, +f.mileage.value || 1, +f.seats.value || 1);
}

document.addEventListener("click", e => {
  const el = e.target.closest("[data-action]");
  if (el) actions[el.dataset.action](el);
});
document.addEventListener("submit", e => {
  e.preventDefault();
  run(() => forms[e.target.dataset.form](e.target), e.target);
});
document.addEventListener("input", e => { if (e.target.closest("[data-form=offer]")) previewCost(); });
document.addEventListener("change", e => {
  const key = e.target.dataset.filter;
  if (!key) return;
  s.filters[key] = e.target.type === "checkbox" ? e.target.checked : e.target.value;
  run(loadRides);
});

/* ---------- start ---------- */
run(async () => {
  if (!store.token) return;
  try { s.user = await api("/me"); await loadAll(); } catch { store.token = ""; s.user = null; }
});
