# RideRelay: campus carpool

Verified campus carpooling with a Node.js backend, SQLite database and a modular browser frontend. No npm install needed (zero dependencies).

## Run
Requires Node 22.13 or newer (uses the built-in `node:sqlite`).

    npm start        # http://localhost:3000
    npm test         # unit tests (logic) + API tests (auth, booking, host confirm, ratings)

Demo accounts: `sneha@campus.edu`, `arjun@campus.edu`, ... all with password `demo1234`.
Or create an account with any `@campus.edu` / `@univ.ac.in` email.

Demo flow: sign up as a rider, search Indiranagar around 08:30, book Sneha's ride (₹45), then sign in as `sneha@campus.edu` and confirm the seat under My rides. Back as the rider, pay via UPI link and rate.

## Structure
    shared/logic.js   pure rules used by server and browser: email domains, fuel split, route matching, validation
    server/server.js  HTTP routes, auth, static files, security headers
    server/db.js      SQLite schema and queries     server/seed.js  12 sample rides
    server/auth.js    scrypt password hashing
    public/js/        api.js (fetch), views.js (pure HTML views), app.js (state and events)
    test/             node:test suites

## Security notes
Passwords are hashed with scrypt; sessions are random tokens; every rule (email domain, seats, ranges, host-only confirm, one booking per rider, seat decrement in a transaction) is enforced on the server. Output is HTML-escaped and a CSP is set.
Not included: email-link verification, login rate limiting, HTTPS, session expiry.
