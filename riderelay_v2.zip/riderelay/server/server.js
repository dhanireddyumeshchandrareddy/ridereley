import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { join, normalize, extname, sep } from "node:path";
import { randomBytes } from "node:crypto";
import { fileURLToPath } from "node:url";
import { db, allRides, rideById } from "./db.js";
import { hashPassword, checkPassword } from "./auth.js";
import { isCampusEmail, nameFromEmail, matchesRide, validateRide, isValidReview } from "../shared/logic.js";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const MIME = { ".html": "text/html", ".css": "text/css", ".js": "text/javascript" };

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const fail = (status, message) => { throw new HttpError(status, message); };

/* ---------- handlers ---------- */
const startSession = userId => {
  const token = randomBytes(24).toString("hex");
  db.prepare("INSERT INTO sessions(token, user_id) VALUES(?, ?)").run(token, userId);
  const user = db.prepare("SELECT id, email, name FROM users WHERE id = ?").get(userId);
  return { token, user };
};

const signup = ({ body }) => {
  const email = String(body.email ?? "").trim().toLowerCase();
  if (!isCampusEmail(email)) fail(400, "Use a @campus.edu or @univ.ac.in email address.");
  if (typeof body.password !== "string" || body.password.length < 8) fail(400, "Password must be at least 8 characters.");
  if (db.prepare("SELECT 1 FROM users WHERE email = ?").get(email)) fail(409, "This email is already registered.");
  const { lastInsertRowid } = db.prepare("INSERT INTO users(email, name, pw) VALUES(?, ?, ?)")
    .run(email, nameFromEmail(email), hashPassword(body.password));
  return startSession(lastInsertRowid);
};

const login = ({ body }) => {
  const user = db.prepare("SELECT id, pw FROM users WHERE email = ?").get(String(body.email ?? "").trim().toLowerCase());
  if (!user || typeof body.password !== "string" || !checkPassword(body.password, user.pw)) fail(401, "Wrong email or password.");
  return startSession(user.id);
};

const logout = ({ token }) => { db.prepare("DELETE FROM sessions WHERE token = ?").run(token); return {}; };

const places = () => [...new Set(allRides().flatMap(r => [r.from, ...r.stops]))].sort();

const listRides = ({ query }) =>
  allRides().filter(r => matchesRide(r, { from: query.from, gate: query.gate, time: query.time, women: query.women === "1" }));

const createRide = ({ user, body }) => {
  const { ride, error } = validateRide(body);
  if (error) fail(400, error);
  const { lastInsertRowid } = db.prepare(`INSERT INTO rides(host_id, origin, stops, time, vehicle, capacity, open, distance, mileage, women, gate)
    VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(user.id, ride.from, JSON.stringify(ride.stops), ride.time, ride.type,
    ride.seats, ride.seats, ride.distance, ride.mileage, ride.women ? 1 : 0, ride.gate);
  return rideById(lastInsertRowid);
};

const bookRide = ({ user, params }) => {
  const ride = rideById(+params.id) ?? fail(404, "Ride not found.");
  if (ride.hostId === user.id) fail(400, "You cannot book your own ride.");
  const id = "RP-" + randomBytes(3).toString("hex").toUpperCase();
  db.exec("BEGIN");
  try {
    if (db.prepare("UPDATE rides SET open = open - 1 WHERE id = ? AND open > 0").run(ride.id).changes === 0) fail(409, "No seats left on this ride.");
    db.prepare("INSERT INTO bookings(id, ride_id, rider_id) VALUES(?, ?, ?)").run(id, ride.id, user.id);
    db.exec("COMMIT");
  } catch (e) {
    db.exec("ROLLBACK");
    throw e instanceof HttpError ? e : /UNIQUE/.test(e.message) ? new HttpError(409, "You already booked this ride.") : e;
  }
  return { id };
};

const myBookings = ({ user }) =>
  db.prepare("SELECT id, ride_id, status, EXISTS(SELECT 1 FROM reviews WHERE booking_id = bookings.id) AS reviewed FROM bookings WHERE rider_id = ?")
    .all(user.id).map(b => ({ id: b.id, status: b.status, reviewed: !!b.reviewed, ride: rideById(b.ride_id) }));

const myHosting = ({ user }) => allRides().filter(r => r.hostId === user.id).map(r => ({
  ...r,
  requests: db.prepare("SELECT b.id, b.status, u.name AS rider FROM bookings b JOIN users u ON u.id = b.rider_id WHERE b.ride_id = ?").all(r.id),
}));

const confirmBooking = ({ user, params }) => {
  const b = db.prepare("SELECT b.id, r.host_id FROM bookings b JOIN rides r ON r.id = b.ride_id WHERE b.id = ?").get(params.id);
  if (!b || b.host_id !== user.id) fail(404, "Booking not found.");
  db.prepare("UPDATE bookings SET status = 'confirmed' WHERE id = ?").run(b.id);
  return {};
};

const reviewBooking = ({ user, params, body }) => {
  const b = db.prepare("SELECT b.status, r.host_id FROM bookings b JOIN rides r ON r.id = b.ride_id WHERE b.id = ? AND b.rider_id = ?").get(params.id, user.id);
  if (!b) fail(404, "Booking not found.");
  if (b.status !== "confirmed") fail(409, "You can rate a ride after the host confirms it.");
  if (!isValidReview(body)) fail(400, "Ratings must be whole numbers from 1 to 5.");
  if (db.prepare("SELECT 1 FROM reviews WHERE booking_id = ?").get(params.id)) fail(409, "You already rated this ride.");
  db.prepare("INSERT INTO reviews(booking_id, punctuality, safety, courtesy) VALUES(?, ?, ?, ?)").run(params.id, body.punctuality, body.safety, body.courtesy);
  db.prepare("UPDATE users SET rating_sum = rating_sum + ?, rating_n = rating_n + 1 WHERE id = ?")
    .run((body.punctuality + body.safety + body.courtesy) / 3, b.host_id);
  return {};
};

/* ---------- routing ---------- */
const route = (method, pattern, auth, handler) =>
  ({ method, re: new RegExp("^" + pattern.replace(/:(\w+)/g, "(?<$1>[^/]+)") + "$"), auth, handler });

const ROUTES = [
  route("POST", "/signup", false, signup),
  route("POST", "/login", false, login),
  route("POST", "/logout", true, logout),
  route("GET", "/me", true, ({ user }) => user),
  route("GET", "/places", true, places),
  route("GET", "/rides", true, listRides),
  route("POST", "/rides", true, createRide),
  route("POST", "/rides/:id/book", true, bookRide),
  route("GET", "/me/bookings", true, myBookings),
  route("GET", "/me/hosting", true, myHosting),
  route("POST", "/bookings/:id/confirm", true, confirmBooking),
  route("POST", "/bookings/:id/review", true, reviewBooking),
];

const readBody = req => new Promise((resolve, reject) => {
  let raw = "";
  req.on("data", c => { if (raw.length <= 10_000) raw += c; });
  req.on("end", () => {
    if (raw.length > 10_000) return reject(new HttpError(413, "Request too large."));
    try { resolve(raw ? JSON.parse(raw) : {}); } catch { reject(new HttpError(400, "Invalid JSON.")); }
  });
});

const send = (res, status, data) => {
  res.writeHead(status, { "Content-Type": "application/json" });
  res.end(JSON.stringify(data));
};

async function handleApi(req, res, url) {
  try {
    const path = url.pathname.slice(4);
    const match = ROUTES.map(r => [r, r.re.exec(path)]).find(([r, m]) => m && r.method === req.method);
    if (!match) fail(404, "Not found.");
    const [{ auth, handler }, m] = match;
    const token = (req.headers.authorization ?? "").replace("Bearer ", "");
    const user = db.prepare("SELECT u.id, u.email, u.name FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?").get(token);
    if (auth && !user) fail(401, "Please sign in.");
    const body = req.method === "POST" ? await readBody(req) : {};
    send(res, 200, handler({ user, token, body, params: { ...m.groups }, query: Object.fromEntries(url.searchParams) }));
  } catch (e) {
    if (!(e instanceof HttpError)) console.error(e);
    send(res, e.status ?? 500, { error: e.status ? e.message : "Server error." });
  }
}

/* ---------- static files ---------- */
async function serveStatic(res, url) {
  const p = url.pathname === "/" ? "/public/index.html" : url.pathname.startsWith("/shared/") ? url.pathname : "/public" + url.pathname;
  const file = normalize(join(ROOT, p));
  const allowed = ["public", "shared"].some(d => file.startsWith(join(ROOT, d) + sep));
  try {
    if (!allowed || !MIME[extname(file)]) throw new Error("blocked");
    const data = await readFile(file); // read first so a failure can still send a clean 404
    res.writeHead(200, { "Content-Type": MIME[extname(file)] });
    res.end(data);
  } catch {
    res.writeHead(404).end("Not found");
  }
}

export const createApp = () => createServer((req, res) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Content-Security-Policy", "default-src 'self'; frame-ancestors 'none'");
  const url = new URL(req.url, "http://localhost");
  return url.pathname.startsWith("/api/") ? handleApi(req, res, url) : serveStatic(res, url);
});

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const port = process.env.PORT || 3000;
  createApp().listen(port, () => console.log(`RideRelay running at http://localhost:${port}`));
}
