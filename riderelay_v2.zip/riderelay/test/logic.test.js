import test from "node:test";
import assert from "node:assert/strict";
import { fuelShare, isCampusEmail, timeGap, matchesRide, validateRide, isValidReview } from "../shared/logic.js";

const ride = { from: "Indiranagar", stops: ["Domlur"], gate: "North Gate", time: "08:30", women: false };

test("fuelShare splits trip fuel across seats plus the driver", () => {
  assert.equal(fuelShare(25, 14, 3), 45);
  assert.equal(fuelShare(22, 40, 1), 28);
});

test("isCampusEmail accepts only the campus domains", () => {
  assert.ok(isCampusEmail("a.b@campus.edu"));
  assert.ok(isCampusEmail("x@univ.ac.in"));
  for (const bad of ["a@gmail.com", "a@campus.edu.evil.com", "a b@campus.edu", "", null, 5]) assert.ok(!isCampusEmail(bad));
});

test("timeGap wraps around midnight", () => {
  assert.equal(timeGap("23:50", "00:10"), 20);
  assert.equal(timeGap("08:00", "09:30"), 90);
});

test("matchesRide checks start, intermediate stop, gate, time window and women-only", () => {
  assert.ok(matchesRide(ride, { from: "Indiranagar" }));
  assert.ok(matchesRide(ride, { from: "Domlur" }));
  assert.ok(!matchesRide(ride, { from: "HSR Layout" }));
  assert.ok(!matchesRide(ride, { gate: "Main Entrance" }));
  assert.ok(matchesRide(ride, { time: "09:25" }));
  assert.ok(!matchesRide(ride, { time: "10:00" }));
  assert.ok(!matchesRide(ride, { women: true }));
});

test("validateRide rejects bad input and accepts a good ride", () => {
  const good = { from: " Koramangala ", stops: ["A", ""], gate: "North Gate", time: "08:15", type: "Car", seats: 2, distance: 20, mileage: 15 };
  assert.equal(validateRide(good).ride.from, "Koramangala");
  assert.deepEqual(validateRide(good).ride.stops, ["A"]);
  for (const patch of [{ seats: 0 }, { seats: 1.5 }, { type: "Two-Wheeler", seats: 2 }, { time: "25:00" }, { distance: "abc" }, { mileage: 0 }, { gate: "Back Door" }]) {
    assert.ok(validateRide({ ...good, ...patch }).error, JSON.stringify(patch));
  }
});

test("isValidReview needs three whole ratings from 1 to 5", () => {
  assert.ok(isValidReview({ punctuality: 5, safety: 4, courtesy: 1 }));
  assert.ok(!isValidReview({ punctuality: 6, safety: 4, courtesy: 1 }));
  assert.ok(!isValidReview({ punctuality: 5, safety: 4 }));
});
