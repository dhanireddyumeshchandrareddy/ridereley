// Pure view functions: state in, HTML string out. All user text goes through esc().
import { GATES, VEHICLES } from "/shared/logic.js";

export const esc = s => String(s).replace(/[&<>"']/g, c => `&#${c.charCodeAt(0)};`);
const options = (list, sel) => list.map(x => `<option ${x === sel ? "selected" : ""}>${esc(x)}</option>`).join("");
const route = r => esc([r.from, ...r.stops, r.gate].join(" → "));
const tag = (text, hi = false) => `<span class="tag${hi ? " hi" : ""}">${text}</span>`;
const errBox = `<div class="err" role="alert"></div>`;

export const loginView = ({ mode }) => `
  <h1>Ride<span>Relay</span></h1>
  <p class="mut">Carpools for verified students and faculty. Use your university email (@campus.edu or @univ.ac.in).</p>
  <form class="card row" data-form="auth">
    <label>University email<input name="email" type="email" required autocomplete="email" placeholder="name@campus.edu"></label>
    <label>Password<input name="password" type="password" required minlength="8" autocomplete="${mode === "login" ? "current-password" : "new-password"}"></label>
    <button>${mode === "login" ? "Sign in" : "Create account"}</button>
    ${errBox}
  </form>
  <button class="ghost" data-action="mode" data-value="${mode === "login" ? "signup" : "login"}">
    ${mode === "login" ? "New here? Create an account" : "Have an account? Sign in"}</button>`;

export const shell = s => {
  const tab = (id, label) => `<button class="${s.tab === id ? "on" : ""}" data-action="tab" data-value="${id}">${label}</button>`;
  const body = { find: findView, offer: offerView, mine: mineView }[s.tab](s);
  return `<header><h1>Ride<span>Relay</span></h1>
    <div class="row"><span class="mut">${esc(s.user.name)} · verified</span><button class="ghost" data-action="signout">Sign out</button></div></header>
    <nav class="tabs">${tab("find", "Find a ride")}${tab("offer", "Offer a ride")}${tab("mine", "My rides")}</nav>
    ${s.error ? `<div class="err" role="alert">${esc(s.error)}</div>` : ""}${body}`;
};

/* ---------- find ---------- */
const findView = ({ filters: f, places, rides, bookings, user }) => `
  <div class="card row">
    <label>Pickup<select data-filter="from"><option value="">Any</option>${options(places, f.from)}</select></label>
    <label>Campus gate<select data-filter="gate"><option value="">Any</option>${options(GATES, f.gate)}</select></label>
    <label>Around<input type="time" data-filter="time" value="${esc(f.time)}"></label>
    <label class="check"><input type="checkbox" data-filter="women" ${f.women ? "checked" : ""}>Women-only</label>
  </div>
  <p class="mut">${rides.length} ride${rides.length === 1 ? "" : "s"} within 1 hour of ${esc(f.time || "any time")}.</p>
  ${rides.map(r => rideCard(r, f, user, bookings)).join("") || `<div class="card mut">No rides match. Widen the time window or clear a filter.</div>`}`;

function rideCard(r, f, user, bookings) {
  const mine = r.hostId === user.id;
  const booked = bookings.some(b => b.ride.id === r.id);
  const label = mine ? "Your ride" : booked ? "Booked" : r.open < 1 ? "Full" : "Book 1 seat";
  return `<div class="card"><div class="row sp">
      <div><b>${esc(r.host)}</b> ${tag("Verified")} ${tag(r.rating ? "★ " + r.rating : "New")}
        ${r.women ? tag("Women-only", true) : ""}${f.from && r.stops.includes(f.from) ? tag("On route", true) : ""}</div>
      <div class="price">₹${r.cost}</div></div>
    <div class="mut">${route(r)}</div>
    <div class="row sp"><span class="mut">${r.time} · ${r.type} · ${r.open} of ${r.capacity} seats open · ${r.distance} km</span>
      <button data-action="book" data-id="${r.id}" ${mine || booked || r.open < 1 ? "disabled" : ""}>${label}</button></div></div>`;
}

/* ---------- offer ---------- */
const offerView = () => `
  <form class="card" data-form="offer"><div class="row">
    <label>Start neighborhood<input name="from" list="places" required maxlength="60" placeholder="e.g. Koramangala"></label>
    <label>Stops on the way<input name="stops" placeholder="Comma separated, optional"></label>
    <label>Campus gate<select name="gate">${options(GATES)}</select></label>
    <label>Departure<input name="time" type="time" value="08:30" required></label>
    <label>Vehicle<select name="type">${options(VEHICLES)}</select></label>
    <label>Seats available<input name="seats" type="number" min="1" max="4" value="2" required></label>
    <label>Distance (km)<input name="distance" type="number" min="1" max="200" step="any" value="20" required></label>
    <label>Mileage (km/l)<input name="mileage" type="number" min="5" max="100" step="any" value="15" required></label>
    <label class="check"><input name="women" type="checkbox">Women-only</label></div>
    <div class="row sp"><div><span class="price" id="cost"></span> <span class="mut">per passenger, shared with the driver</span></div>
      <button>Publish ride</button></div>
    ${errBox}
  </form>`;

/* ---------- my rides ---------- */
const mineView = ({ bookings, hosting }) => `
  <h2>Ride passes</h2>
  ${bookings.map(passCard).join("") || `<div class="card mut">No bookings yet. Find a ride and book a seat.</div>`}
  <h2>Rides you offer</h2>
  ${hosting.map(hostCard).join("") || `<div class="card mut">You have not offered a ride yet.</div>`}`;

function passCard(b) {
  const r = b.ride, ok = b.status === "confirmed";
  const upi = `upi://pay?pa=${encodeURIComponent(r.contact.split("@")[0])}@upi&pn=${encodeURIComponent(r.host)}&am=${r.cost}&cu=INR&tn=${encodeURIComponent("RideRelay " + b.id)}`;
  const score = name => `<label>${name[0].toUpperCase() + name.slice(1)}<select name="${name}">${[5, 4, 3, 2, 1].map(n => `<option>${n}</option>`).join("")}</select></label>`;
  return `<div class="card pass"><div class="row sp"><b>Ride pass ${esc(b.id)}</b>${tag(ok ? "Confirmed by host" : "Waiting for host", ok)}</div>
    <div>${route(r)}</div>
    <div class="mut">Departs ${r.time} · ${r.type} · Meet at ${esc(r.gate)} · Host ${esc(r.host)} (${esc(r.contact)})</div>
    <div class="price">₹${r.cost}</div>
    ${!ok ? "" : `<a class="btn" href="${upi}">Pay ₹${r.cost} via UPI</a>
      ${b.reviewed ? `<p class="mut">Thanks, your rating was saved.</p>` : `
      <form class="row" data-form="review" data-id="${esc(b.id)}">${["punctuality", "safety", "courtesy"].map(score).join("")}
        <button>Submit rating</button>${errBox}</form>`}`}</div>`;
}

const hostCard = r => `<div class="card"><b>${route(r)}</b>
  <div class="mut">${r.time} · ${r.type} · ${r.open} of ${r.capacity} seats open · ₹${r.cost} each</div>
  ${r.requests.map(q => `<div class="row sp"><span>${esc(q.rider)} · ${q.status}</span>
    ${q.status === "pending" ? `<button data-action="confirm" data-id="${esc(q.id)}">Confirm seat</button>` : ""}</div>`).join("")}</div>`;
