import { GATES } from "../shared/logic.js";
import { hashPassword } from "./auth.js";

// name, rating, from, stops, time, vehicle, capacity, open, km, km/l, women-only, gate index
const RIDES = [
  ["Sneha", 4.9, "Indiranagar", ["Domlur"], "08:30", "Car", 3, 2, 25, 14, 0, 0],
  ["Arjun", 4.7, "Koramangala", ["Madiwala"], "08:15", "Two-Wheeler", 1, 1, 22, 40, 0, 1],
  ["Meera", 4.8, "HSR Layout", ["Bellandur"], "08:45", "Car", 3, 3, 20, 15, 1, 2],
  ["Rohan", 4.5, "Whitefield", ["Brookefield", "Marathahalli"], "07:50", "Car", 4, 2, 30, 13, 0, 0],
  ["Kavya", 4.9, "Indiranagar", ["Domlur", "Marathahalli"], "09:00", "Car", 2, 1, 24, 16, 1, 1],
  ["Dev", 4.3, "Koramangala", ["Bellandur"], "08:30", "Two-Wheeler", 1, 0, 20, 35, 0, 2],
  ["Prof. Iyer", 4.8, "HSR Layout", ["Silk Board", "Bellandur"], "08:00", "Car", 3, 3, 21, 14, 0, 0],
  ["Ananya", 4.6, "Whitefield", ["Brookefield"], "08:20", "Two-Wheeler", 1, 1, 28, 38, 1, 1],
  ["Imran", 4.4, "Koramangala", ["Madiwala", "Silk Board"], "08:10", "Car", 3, 2, 22, 15, 0, 0],
  ["Divya", 4.9, "Indiranagar", ["Domlur"], "08:35", "Car", 2, 2, 24, 16, 1, 2],
  ["Karthik", 4.2, "HSR Layout", ["Bellandur"], "09:15", "Two-Wheeler", 1, 1, 19, 42, 0, 2],
  ["Dr. Rao", 4.7, "Whitefield", ["Brookefield", "Marathahalli", "Bellandur"], "08:40", "Car", 4, 3, 32, 12, 0, 0],
];

// Demo hosts (e.g. sneha@campus.edu) all share the password "demo1234".
export function seedIfEmpty(db) {
  if (db.prepare("SELECT 1 FROM users LIMIT 1").get()) return;
  const pw = hashPassword("demo1234");
  const addUser = db.prepare("INSERT INTO users(email, name, pw, rating_sum, rating_n) VALUES(?, ?, ?, ?, 10)");
  const addRide = db.prepare(`INSERT INTO rides(host_id, origin, stops, time, vehicle, capacity, open, distance, mileage, women, gate)
                              VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  for (const [name, rating, from, stops, time, type, cap, open, km, mil, women, gate] of RIDES) {
    const { lastInsertRowid: id } = addUser.run(`${name.toLowerCase().replace(/[^a-z]/g, "")}@campus.edu`, name, pw, rating * 10);
    addRide.run(id, from, JSON.stringify(stops), time, type, cap, open, km, mil, women, GATES[gate]);
  }
}
