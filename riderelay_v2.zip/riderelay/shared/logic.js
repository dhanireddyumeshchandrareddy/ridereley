// Pure business rules, shared by the server (validation) and the browser (live preview).
export const DOMAINS = ["campus.edu", "univ.ac.in"];
export const GATES = ["Main Entrance", "North Gate", "Canteen Circle"];
export const VEHICLES = ["Car", "Two-Wheeler"];
export const FUEL_PRICE = 100; // Rs per litre

const emailRe = new RegExp(`^[^@\\s]+@(${DOMAINS.map(d => d.replace(".", "\\.")).join("|")})$`, "i");
export const isCampusEmail = e => typeof e === "string" && e.length <= 100 && emailRe.test(e);
export const nameFromEmail = e => {
  const n = e.split("@")[0].replace(/[._]/g, " ");
  return n.charAt(0).toUpperCase() + n.slice(1);
};

// Fuel for the whole trip is shared by every seat plus the driver.
export const fuelShare = (distance, mileage, seats) => Math.round(distance / mileage * FUEL_PRICE / (seats + 1));

const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
export const isTime = t => typeof t === "string" && TIME_RE.test(t);
export const toMinutes = t => +t.slice(0, 2) * 60 + +t.slice(3);
export const timeGap = (a, b) => {
  const d = Math.abs(toMinutes(a) - toMinutes(b));
  return Math.min(d, 1440 - d); // handles wraparound across midnight
};

// Milestone matching: the rider's pickup may be the start or any intermediate stop.
export const matchesRide = (ride, q = {}) => {
  if (q.from && ride.from !== q.from && !ride.stops.includes(q.from)) return false;
  if (q.gate && ride.gate !== q.gate) return false;
  if (isTime(q.time) && timeGap(ride.time, q.time) > 60) return false;
  return !q.women || ride.women;
};

const inRange = (v, lo, hi) => Number.isFinite(v) && v >= lo && v <= hi;
const clean = s => (typeof s === "string" ? s.trim().slice(0, 60) : "");

export function validateRide(b = {}) {
  const ride = {
    from: clean(b.from),
    stops: (Array.isArray(b.stops) ? b.stops : []).map(clean).filter(Boolean).slice(0, 6),
    gate: b.gate, time: b.time, type: b.type, women: !!b.women,
    seats: Number(b.seats), distance: Number(b.distance), mileage: Number(b.mileage),
  };
  const maxSeats = ride.type === "Two-Wheeler" ? 1 : 4;
  const error =
    !ride.from ? "Enter a start neighborhood." :
    !GATES.includes(ride.gate) ? "Choose a campus gate." :
    !isTime(ride.time) ? "Enter a valid departure time." :
    !VEHICLES.includes(ride.type) ? "Choose a vehicle." :
    !Number.isInteger(ride.seats) || !inRange(ride.seats, 1, maxSeats) ? `Seats must be 1 to ${maxSeats}.` :
    !inRange(ride.distance, 1, 200) ? "Distance must be 1 to 200 km." :
    !inRange(ride.mileage, 5, 100) ? "Mileage must be 5 to 100 km/l." : null;
  return error ? { error } : { ride };
}

export const isValidReview = b =>
  ["punctuality", "safety", "courtesy"].every(k => Number.isInteger(b?.[k]) && b[k] >= 1 && b[k] <= 5);
