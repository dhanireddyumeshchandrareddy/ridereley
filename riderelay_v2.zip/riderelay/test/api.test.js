import test, { after } from "node:test";
import assert from "node:assert/strict";
import { once } from "node:events";

process.env.DB_FILE = ":memory:";
const { createApp } = await import("../server/server.js");
const server = createApp().listen(0);
await once(server, "listening");
const base = `http://localhost:${server.address().port}/api`;
after(() => server.close());

const call = async (path, { method = "GET", body, token } = {}) => {
  const res = await fetch(base + path, {
    method,
    headers: { "Content-Type": "application/json", ...(token && { Authorization: `Bearer ${token}` }) },
    body: body && JSON.stringify(body),
  });
  return { status: res.status, data: await res.json() };
};

test("signup rejects non-campus emails and short passwords", async () => {
  assert.equal((await call("/signup", { method: "POST", body: { email: "a@gmail.com", password: "password1" } })).status, 400);
  assert.equal((await call("/signup", { method: "POST", body: { email: "a@campus.edu", password: "short" } })).status, 400);
});

test("api requires a session", async () => {
  assert.equal((await call("/rides")).status, 401);
});

test("booking, host confirmation and rating flow", async () => {
  const rider = (await call("/signup", { method: "POST", body: { email: "asha@campus.edu", password: "password1" } })).data.token;
  const host = (await call("/login", { method: "POST", body: { email: "sneha@campus.edu", password: "demo1234" } })).data.token;

  const [ride] = (await call("/rides?from=Indiranagar&time=08:30", { token: rider })).data.filter(r => r.host === "Sneha");
  assert.equal(ride.cost, 45);
  assert.equal(ride.open, 2);

  const booked = await call(`/rides/${ride.id}/book`, { method: "POST", token: rider });
  assert.equal(booked.status, 200);
  assert.equal((await call(`/rides/${ride.id}/book`, { method: "POST", token: rider })).status, 409); // no double booking
  assert.equal((await call(`/rides/${ride.id}/book`, { method: "POST", token: host })).status, 400); // not your own ride

  const rating = { method: "POST", token: rider, body: { punctuality: 5, safety: 5, courtesy: 5 } };
  assert.equal((await call(`/bookings/${booked.data.id}/review`, rating)).status, 409); // not confirmed yet
  assert.equal((await call(`/bookings/${booked.data.id}/confirm`, { method: "POST", token: rider })).status, 404); // only the host
  assert.equal((await call(`/bookings/${booked.data.id}/confirm`, { method: "POST", token: host })).status, 200);
  assert.equal((await call(`/bookings/${booked.data.id}/review`, rating)).status, 200);
  assert.equal((await call(`/bookings/${booked.data.id}/review`, rating)).status, 409); // only once

  const after = (await call("/rides?from=Indiranagar", { token: rider })).data.find(r => r.host === "Sneha");
  assert.equal(after.open, 1);
});

test("full rides cannot be booked", async () => {
  const token = (await call("/signup", { method: "POST", body: { email: "ravi@univ.ac.in", password: "password1" } })).data.token;
  const full = (await call("/rides", { token })).data.find(r => r.open === 0);
  assert.equal((await call(`/rides/${full.id}/book`, { method: "POST", token })).status, 409);
});

test("offering a ride validates input", async () => {
  const token = (await call("/login", { method: "POST", body: { email: "asha@campus.edu", password: "password1" } })).data.token;
  const bad = await call("/rides", { method: "POST", token, body: { from: "X", gate: "North Gate", time: "08:00", type: "Two-Wheeler", seats: 3, distance: 10, mileage: 30 } });
  assert.equal(bad.status, 400);
  const ok = await call("/rides", { method: "POST", token, body: { from: "Hebbal", stops: ["Manyata"], gate: "North Gate", time: "08:00", type: "Car", seats: 2, distance: 18, mileage: 15 } });
  assert.equal(ok.status, 200);
});

test("static files: app is served, server source is not", async () => {
  const root = base.replace("/api", "");
  assert.equal((await fetch(root + "/")).status, 200);
  assert.equal((await fetch(root + "/shared/logic.js")).status, 200);
  assert.equal((await fetch(root + "/server/db.js")).status, 404);
  assert.equal((await fetch(root + "/missing.js")).status, 404);
});
