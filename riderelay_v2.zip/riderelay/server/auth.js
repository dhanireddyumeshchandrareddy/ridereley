import { scryptSync, randomBytes, timingSafeEqual } from "node:crypto";

export const hashPassword = pw => {
  const salt = randomBytes(16);
  return `${salt.toString("hex")}:${scryptSync(pw, salt, 32).toString("hex")}`;
};

export const checkPassword = (pw, stored) => {
  const [salt, hash] = stored.split(":");
  return timingSafeEqual(Buffer.from(hash, "hex"), scryptSync(pw, Buffer.from(salt, "hex"), 32));
};
