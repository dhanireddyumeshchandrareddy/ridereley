import { DatabaseSync } from "node:sqlite";
import { fuelShare } from "../shared/logic.js";
import { seedIfEmpty } from "./seed.js";

export const db = new DatabaseSync(process.env.DB_FILE || "riderelay.db");
db.exec(`
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT NOT NULL, pw TEXT NOT NULL,
    rating_sum REAL NOT NULL DEFAULT 0, rating_n INTEGER NOT NULL DEFAULT 0);
  CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id));
  CREATE TABLE IF NOT EXISTS rides(
    id INTEGER PRIMARY KEY, host_id INTEGER NOT NULL REFERENCES users(id),
    origin TEXT NOT NULL, stops TEXT NOT NULL, time TEXT NOT NULL, vehicle TEXT NOT NULL,
    capacity INTEGER NOT NULL, open INTEGER NOT NULL CHECK(open >= 0),
    distance REAL NOT NULL, mileage REAL NOT NULL, women INTEGER NOT NULL, gate TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS bookings(
    id TEXT PRIMARY KEY, ride_id INTEGER NOT NULL REFERENCES rides(id),
    rider_id INTEGER NOT NULL REFERENCES users(id), status TEXT NOT NULL DEFAULT 'pending',
    UNIQUE(ride_id, rider_id));
  CREATE TABLE IF NOT EXISTS reviews(
    booking_id TEXT PRIMARY KEY REFERENCES bookings(id),
    punctuality INTEGER NOT NULL, safety INTEGER NOT NULL, courtesy INTEGER NOT NULL);
`);
seedIfEmpty(db);

const RIDE_SELECT = `SELECT r.*, u.name AS host, u.email AS contact,
  ROUND(u.rating_sum * 1.0 / NULLIF(u.rating_n, 0), 1) AS rating
  FROM rides r JOIN users u ON u.id = r.host_id`;

const toRide = r => ({
  id: r.id, hostId: r.host_id, host: r.host, contact: r.contact, rating: r.rating,
  from: r.origin, stops: JSON.parse(r.stops), time: r.time, type: r.vehicle,
  capacity: r.capacity, open: r.open, distance: r.distance, mileage: r.mileage,
  women: !!r.women, gate: r.gate, cost: fuelShare(r.distance, r.mileage, r.capacity),
});

export const allRides = () => db.prepare(RIDE_SELECT + " ORDER BY r.time").all().map(toRide);
export const rideById = id => {
  const row = db.prepare(RIDE_SELECT + " WHERE r.id = ?").get(id);
  return row && toRide(row);
};
